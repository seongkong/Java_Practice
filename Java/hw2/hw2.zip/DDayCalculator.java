import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class DDayCalculator {
    public static void main(String[] args) {
        // Input the Start Date
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter a start date:");
        String startDateStr = scanner.nextLine();
        LocalDate startDate = parseDate(startDateStr);

        // Input End Date
        System.out.println("Enter an end date:");
        String endDateStr = scanner.nextLine();
        LocalDate endDate = parseDate(endDateStr);

        // Calculate D-Days
        long daysUntilEndDate = ChronoUnit.DAYS.between(startDate, endDate);

        // Print the result
        System.out.println("D-day: " + daysUntilEndDate + " days.");

        scanner.close();
    }

    // String convert to Local Date
    private static LocalDate parseDate(String dateStr) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        return LocalDate.parse(dateStr, formatter);
    }
}
